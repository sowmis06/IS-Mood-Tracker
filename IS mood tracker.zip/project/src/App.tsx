import React, { useState } from 'react';
import { Heart, Calendar, BarChart3, User } from 'lucide-react';
import MoodEntry from './components/MoodEntry';
import MoodCalendar from './components/MoodCalendar';
import MoodStats from './components/MoodStats';
import ThemeToggle from './components/ThemeToggle';
import { useMoodData } from './hooks/useMoodData';
import { useTheme } from './hooks/useTheme';

type Tab = 'entry' | 'calendar' | 'stats';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('entry');
  const { loading } = useMoodData();
  useTheme(); // Initialize theme

  const tabs = [
    { id: 'entry' as Tab, label: 'Track Mood', icon: Heart },
    { id: 'calendar' as Tab, label: 'Calendar', icon: Calendar },
    { id: 'stats' as Tab, label: 'Statistics', icon: BarChart3 },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading your mood data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900 transition-colors duration-500">
      {/* Header */}
      <header className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
                <Heart className="h-6 w-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold">MoodTracker</h1>
                <p className="text-xs opacity-90">Track your emotional journey</p>
              </div>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white/80 dark:bg-gray-800/80 backdrop-blur-lg border-b border-white/20 dark:border-gray-600/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`
                    flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-all duration-200
                    ${activeTab === tab.id
                      ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                      : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                    }
                  `}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-fadeIn">
          {activeTab === 'entry' && <MoodEntry />}
          {activeTab === 'calendar' && <MoodCalendar />}
          {activeTab === 'stats' && <MoodStats />}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm border-t border-white/20 dark:border-gray-600/20 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="text-center text-sm text-gray-500 dark:text-gray-400">
            <p>Made with ❤️ for tracking your emotional well-being</p>
            <p className="mt-1">Your data is stored locally and never shared</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;