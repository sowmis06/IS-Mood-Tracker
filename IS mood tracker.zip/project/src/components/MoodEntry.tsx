import React, { useState, useEffect } from 'react';
import { Plus, Save, X } from 'lucide-react';
import MoodSelector from './MoodSelector';
import { useMoodData } from '../hooks/useMoodData';
import { getDateString, formatDate } from '../utils/dateUtils';

const MoodEntry: React.FC = () => {
  const { addEntry, updateEntry, getEntryByDate } = useMoodData();
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [note, setNote] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [currentDate] = useState(() => getDateString(new Date()));

  useEffect(() => {
    // Check if there's already an entry for today
    const existingEntry = getEntryByDate(currentDate);
    if (existingEntry) {
      setSelectedMood(existingEntry.mood);
      setNote(existingEntry.note);
      setTags(existingEntry.tags);
      setIsEditing(true);
    }
  }, [currentDate, getEntryByDate]);

  const handleSave = () => {
    if (selectedMood === null) return;

    const entryData = {
      date: currentDate,
      mood: selectedMood,
      note: note.trim(),
      tags,
    };

    if (isEditing) {
      const existingEntry = getEntryByDate(currentDate);
      if (existingEntry) {
        updateEntry(existingEntry.id, entryData);
      }
    } else {
      addEntry(entryData);
      setIsEditing(true);
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput('');
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    setTags(tags.filter(tag => tag !== tagToRemove));
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleAddTag();
    }
  };

  return (
    <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-3xl p-8 shadow-xl border border-white/20 dark:border-gray-600/20">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-2">
          {isEditing ? 'Update Your Mood' : 'Track Your Mood'}
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          {formatDate(currentDate)}
        </p>
      </div>

      <MoodSelector
        selectedMood={selectedMood}
        onMoodSelect={setSelectedMood}
        className="mb-8"
      />

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            How was your day? (Optional)
          </label>
          <textarea
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Share your thoughts, feelings, or what happened today..."
            className="w-full p-4 border border-gray-200 dark:border-gray-600 rounded-xl bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-blue-500/30 resize-none transition-all duration-200"
            rows={4}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Tags (Optional)
          </label>
          <div className="flex space-x-2 mb-3">
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Add a tag (work, family, exercise...)"
              className="flex-1 p-3 border border-gray-200 dark:border-gray-600 rounded-xl bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm text-gray-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-4 focus:ring-blue-500/30 transition-all duration-200"
            />
            <button
              onClick={handleAddTag}
              className="px-4 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-xl transition-colors duration-200 focus:outline-none focus:ring-4 focus:ring-blue-500/30"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
          {tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 border border-blue-200 dark:border-blue-700"
                >
                  {tag}
                  <button
                    onClick={() => handleRemoveTag(tag)}
                    className="ml-2 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-200"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>

        <button
          onClick={handleSave}
          disabled={selectedMood === null}
          className="w-full py-4 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500 text-white font-semibold rounded-xl transition-all duration-200 transform hover:scale-105 disabled:scale-100 disabled:cursor-not-allowed focus:outline-none focus:ring-4 focus:ring-blue-500/30 flex items-center justify-center space-x-2"
        >
          <Save className="w-5 h-5" />
          <span>{isEditing ? 'Update Entry' : 'Save Entry'}</span>
        </button>
      </div>
    </div>
  );
};

export default MoodEntry;