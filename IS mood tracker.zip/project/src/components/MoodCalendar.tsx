import React, { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useMoodData } from '../hooks/useMoodData';
import { getDaysInMonth, getFirstDayOfMonth, getMonthName, getDateString } from '../utils/dateUtils';
import { getMoodEmoji, getMoodBgColor } from '../utils/moodUtils';

const MoodCalendar: React.FC = () => {
  const { getEntryByDate } = useMoodData();
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  
  const previousMonth = () => {
    setCurrentDate(new Date(year, month - 1));
  };
  
  const nextMonth = () => {
    setCurrentDate(new Date(year, month + 1));
  };

  const renderCalendarDays = () => {
    const days = [];
    const today = new Date();
    
    // Empty cells for days before the first day of the month
    for (let i = 0; i < firstDay; i++) {
      days.push(<div key={`empty-${i}`} className="h-12"></div>);
    }
    
    // Days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(year, month, day);
      const dateString = getDateString(date);
      const entry = getEntryByDate(dateString);
      const isToday = 
        date.getDate() === today.getDate() &&
        date.getMonth() === today.getMonth() &&
        date.getFullYear() === today.getFullYear();
      
      days.push(
        <div
          key={day}
          className={`
            h-12 w-12 rounded-xl flex items-center justify-center text-sm font-medium relative transition-all duration-200
            ${entry 
              ? `${getMoodBgColor(entry.mood)} text-gray-800 dark:text-white shadow-sm border border-white/30 dark:border-gray-600/30` 
              : 'text-gray-400 dark:text-gray-600 hover:bg-gray-100 dark:hover:bg-gray-800/50'
            }
            ${isToday ? 'ring-2 ring-blue-500 ring-offset-2 dark:ring-offset-gray-900' : ''}
          `}
        >
          <span className="z-10">{day}</span>
          {entry && (
            <span className="absolute top-0 right-0 text-xs transform translate-x-1 -translate-y-1">
              {getMoodEmoji(entry.mood)}
            </span>
          )}
        </div>
      );
    }
    
    return days;
  };

  return (
    <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-3xl p-6 shadow-xl border border-white/20 dark:border-gray-600/20">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={previousMonth}
          className="p-2 rounded-xl bg-white/60 dark:bg-gray-800/60 hover:bg-white/80 dark:hover:bg-gray-800/80 transition-colors duration-200 focus:outline-none focus:ring-4 focus:ring-blue-500/30"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        </button>
        
        <h3 className="text-xl font-bold text-gray-800 dark:text-white">
          {getMonthName(month)} {year}
        </h3>
        
        <button
          onClick={nextMonth}
          className="p-2 rounded-xl bg-white/60 dark:bg-gray-800/60 hover:bg-white/80 dark:hover:bg-gray-800/80 transition-colors duration-200 focus:outline-none focus:ring-4 focus:ring-blue-500/30"
        >
          <ChevronRight className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        </button>
      </div>
      
      <div className="grid grid-cols-7 gap-2 mb-4">
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
          <div key={day} className="h-8 flex items-center justify-center text-sm font-medium text-gray-500 dark:text-gray-400">
            {day}
          </div>
        ))}
      </div>
      
      <div className="grid grid-cols-7 gap-2">
        {renderCalendarDays()}
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
        <div className="flex items-center justify-center space-x-4 text-xs text-gray-500 dark:text-gray-400">
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-red-200 dark:bg-red-900/40 rounded"></div>
            <span>Sad</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-yellow-200 dark:bg-yellow-900/40 rounded"></div>
            <span>Neutral</span>
          </div>
          <div className="flex items-center space-x-1">
            <div className="w-3 h-3 bg-green-200 dark:bg-green-900/40 rounded"></div>
            <span>Happy</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MoodCalendar;