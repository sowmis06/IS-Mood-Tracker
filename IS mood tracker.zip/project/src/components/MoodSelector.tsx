import React from 'react';
import { getMoodEmoji, getMoodLabel, getMoodColor } from '../utils/moodUtils';

interface MoodSelectorProps {
  selectedMood: number | null;
  onMoodSelect: (mood: number) => void;
  className?: string;
}

const MoodSelector: React.FC<MoodSelectorProps> = ({
  selectedMood,
  onMoodSelect,
  className = '',
}) => {
  const moods = [1, 2, 3, 4, 5];

  return (
    <div className={`space-y-4 ${className}`}>
      <h3 className="text-lg font-semibold text-gray-700 dark:text-gray-300 text-center">
        How are you feeling today?
      </h3>
      <div className="flex justify-center space-x-2">
        {moods.map((mood) => (
          <button
            key={mood}
            onClick={() => onMoodSelect(mood)}
            className={`
              relative p-4 rounded-2xl transition-all duration-300 transform hover:scale-110
              ${selectedMood === mood 
                ? `bg-gradient-to-br ${getMoodColor(mood)} text-white shadow-xl scale-110` 
                : 'bg-white/60 dark:bg-gray-800/60 text-gray-600 dark:text-gray-400 hover:bg-white/80 dark:hover:bg-gray-800/80'
              }
              backdrop-blur-sm border border-white/20 dark:border-gray-600/20
              focus:outline-none focus:ring-4 focus:ring-blue-500/30
            `}
          >
            <div className="flex flex-col items-center space-y-2">
              <span className="text-3xl" role="img" aria-label={getMoodLabel(mood)}>
                {getMoodEmoji(mood)}
              </span>
              <span className="text-xs font-medium whitespace-nowrap">
                {getMoodLabel(mood)}
              </span>
            </div>
            {selectedMood === mood && (
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-white rounded-full flex items-center justify-center">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default MoodSelector;