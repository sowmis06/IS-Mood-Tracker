import React from 'react';
import { TrendingUp, Calendar, Target, BarChart3, Download } from 'lucide-react';
import { useMoodData } from '../hooks/useMoodData';
import { getMoodEmoji, getMoodLabel, getMoodColor } from '../utils/moodUtils';

const MoodStats: React.FC = () => {
  const { getStats, exportData } = useMoodData();
  const stats = getStats();

  const StatCard: React.FC<{
    icon: React.ReactNode;
    title: string;
    value: string | number;
    subtitle?: string;
    gradient: string;
  }> = ({ icon, title, value, subtitle, gradient }) => (
    <div className={`bg-gradient-to-br ${gradient} p-6 rounded-2xl text-white shadow-lg transform hover:scale-105 transition-all duration-200`}>
      <div className="flex items-center justify-between mb-4">
        <div className="p-2 bg-white/20 rounded-xl backdrop-blur-sm">
          {icon}
        </div>
      </div>
      <div className="space-y-1">
        <p className="text-2xl font-bold">{value}</p>
        <p className="text-sm opacity-90">{title}</p>
        {subtitle && <p className="text-xs opacity-75">{subtitle}</p>}
      </div>
    </div>
  );

  const renderMoodDistribution = () => {
    const maxCount = Math.max(...Object.values(stats.moodDistribution));
    
    return (
      <div className="space-y-3">
        {[5, 4, 3, 2, 1].map((mood) => {
          const count = stats.moodDistribution[mood] || 0;
          const percentage = maxCount > 0 ? (count / maxCount) * 100 : 0;
          
          return (
            <div key={mood} className="flex items-center space-x-3">
              <span className="text-2xl w-10" role="img" aria-label={getMoodLabel(mood)}>
                {getMoodEmoji(mood)}
              </span>
              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {getMoodLabel(mood)}
                  </span>
                  <span className="text-sm text-gray-500 dark:text-gray-400">
                    {count} times
                  </span>
                </div>
                <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                  <div
                    className={`bg-gradient-to-r ${getMoodColor(mood)} h-2 rounded-full transition-all duration-500 ease-out`}
                    style={{ width: `${percentage}%` }}
                  ></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  const renderWeeklyTrend = () => {
    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const maxMood = Math.max(...stats.weeklyTrend.filter(m => m > 0));
    
    return (
      <div className="flex items-end justify-between space-x-2 h-32">
        {stats.weeklyTrend.map((mood, index) => {
          const height = mood > 0 ? (mood / maxMood) * 100 : 0;
          
          return (
            <div key={index} className="flex flex-col items-center space-y-2 flex-1">
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-t-lg relative overflow-hidden" style={{ height: '80px' }}>
                {mood > 0 && (
                  <div
                    className={`absolute bottom-0 w-full bg-gradient-to-t ${getMoodColor(mood)} rounded-t-lg transition-all duration-700 ease-out flex items-end justify-center pb-1`}
                    style={{ height: `${height}%` }}
                  >
                    <span className="text-xs text-white font-bold">
                      {getMoodEmoji(mood)}
                    </span>
                  </div>
                )}
              </div>
              <span className="text-xs font-medium text-gray-500 dark:text-gray-400">
                {days[index]}
              </span>
            </div>
          );
        })}
      </div>
    );
  };

  if (stats.totalEntries === 0) {
    return (
      <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-3xl p-8 shadow-xl border border-white/20 dark:border-gray-600/20 text-center">
        <div className="text-6xl mb-4">📊</div>
        <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">No Data Yet</h3>
        <p className="text-gray-600 dark:text-gray-400">
          Start tracking your mood to see insights and statistics here!
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={<TrendingUp className="w-6 h-6" />}
          title="Average Mood"
          value={`${stats.averageMood.toFixed(1)}/5`}
          subtitle={getMoodLabel(Math.round(stats.averageMood))}
          gradient="from-blue-500 to-purple-600"
        />
        <StatCard
          icon={<Calendar className="w-6 h-6" />}
          title="Total Entries"
          value={stats.totalEntries}
          subtitle="Days tracked"
          gradient="from-green-500 to-teal-600"
        />
        <StatCard
          icon={<Target className="w-6 h-6" />}
          title="Current Streak"
          value={stats.streakDays}
          subtitle="Consecutive days"
          gradient="from-orange-500 to-red-600"
        />
        <StatCard
          icon={<BarChart3 className="w-6 h-6" />}
          title="Most Common"
          value={getMoodEmoji(Number(Object.keys(stats.moodDistribution).reduce((a, b) => 
            stats.moodDistribution[Number(a)] > stats.moodDistribution[Number(b)] ? a : b
          )))}
          subtitle="Mood state"
          gradient="from-pink-500 to-rose-600"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Mood Distribution */}
        <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-3xl p-6 shadow-xl border border-white/20 dark:border-gray-600/20">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center space-x-2">
            <BarChart3 className="w-5 h-5" />
            <span>Mood Distribution</span>
          </h3>
          {renderMoodDistribution()}
        </div>

        {/* Weekly Trend */}
        <div className="bg-white/70 dark:bg-gray-800/70 backdrop-blur-lg rounded-3xl p-6 shadow-xl border border-white/20 dark:border-gray-600/20">
          <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center space-x-2">
            <TrendingUp className="w-5 h-5" />
            <span>Weekly Trend</span>
          </h3>
          {renderWeeklyTrend()}
        </div>
      </div>

      {/* Export Button */}
      <div className="text-center">
        <button
          onClick={exportData}
          className="inline-flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white font-semibold rounded-xl transition-all duration-200 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-indigo-500/30"
        >
          <Download className="w-5 h-5" />
          <span>Export Data</span>
        </button>
      </div>
    </div>
  );
};

export default MoodStats;