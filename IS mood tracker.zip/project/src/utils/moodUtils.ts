export const getMoodEmoji = (mood: number): string => {
  const moodEmojis = {
    1: '😢',
    2: '😟',
    3: '😐',
    4: '😊',
    5: '😁',
  };
  return moodEmojis[mood as keyof typeof moodEmojis] || '😐';
};

export const getMoodLabel = (mood: number): string => {
  const moodLabels = {
    1: 'Very Sad',
    2: 'Sad',
    3: 'Neutral',
    4: 'Happy',
    5: 'Very Happy',
  };
  return moodLabels[mood as keyof typeof moodLabels] || 'Neutral';
};

export const getMoodColor = (mood: number): string => {
  const moodColors = {
    1: 'from-red-400 to-red-600',
    2: 'from-orange-400 to-orange-600',
    3: 'from-yellow-400 to-yellow-600',
    4: 'from-green-400 to-green-600',
    5: 'from-emerald-400 to-emerald-600',
  };
  return moodColors[mood as keyof typeof moodColors] || 'from-gray-400 to-gray-600';
};

export const getMoodBgColor = (mood: number): string => {
  const moodBgColors = {
    1: 'bg-red-100 dark:bg-red-900/20',
    2: 'bg-orange-100 dark:bg-orange-900/20',
    3: 'bg-yellow-100 dark:bg-yellow-900/20',
    4: 'bg-green-100 dark:bg-green-900/20',
    5: 'bg-emerald-100 dark:bg-emerald-900/20',
  };
  return moodBgColors[mood as keyof typeof moodBgColors] || 'bg-gray-100 dark:bg-gray-900/20';
};