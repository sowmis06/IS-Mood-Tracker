export interface MoodEntry {
  id: string;
  date: string;
  mood: number; // 1-5 scale
  note: string;
  tags: string[];
  timestamp: number;
}

export interface MoodStats {
  averageMood: number;
  totalEntries: number;
  streakDays: number;
  moodDistribution: { [key: number]: number };
  weeklyTrend: number[];
}

export type Theme = 'light' | 'dark';