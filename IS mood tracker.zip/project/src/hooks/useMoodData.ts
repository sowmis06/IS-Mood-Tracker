import { useState, useEffect } from 'react';
import { MoodEntry, MoodStats } from '../types/mood';

const STORAGE_KEY = 'mood-tracker-data';

export const useMoodData = () => {
  const [entries, setEntries] = useState<MoodEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setEntries(JSON.parse(stored));
      } catch (error) {
        console.error('Error loading mood data:', error);
      }
    }
    setLoading(false);
  }, []);

  const saveEntries = (newEntries: MoodEntry[]) => {
    setEntries(newEntries);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newEntries));
  };

  const addEntry = (entry: Omit<MoodEntry, 'id' | 'timestamp'>) => {
    const newEntry: MoodEntry = {
      ...entry,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
    };
    const newEntries = [...entries, newEntry];
    saveEntries(newEntries);
  };

  const updateEntry = (id: string, updates: Partial<MoodEntry>) => {
    const newEntries = entries.map(entry =>
      entry.id === id ? { ...entry, ...updates } : entry
    );
    saveEntries(newEntries);
  };

  const deleteEntry = (id: string) => {
    const newEntries = entries.filter(entry => entry.id !== id);
    saveEntries(newEntries);
  };

  const getEntryByDate = (date: string): MoodEntry | undefined => {
    return entries.find(entry => entry.date === date);
  };

  const getStats = (): MoodStats => {
    if (entries.length === 0) {
      return {
        averageMood: 0,
        totalEntries: 0,
        streakDays: 0,
        moodDistribution: {},
        weeklyTrend: [],
      };
    }

    const totalMood = entries.reduce((sum, entry) => sum + entry.mood, 0);
    const averageMood = totalMood / entries.length;

    const moodDistribution = entries.reduce((dist, entry) => {
      dist[entry.mood] = (dist[entry.mood] || 0) + 1;
      return dist;
    }, {} as { [key: number]: number });

    // Calculate current streak
    const sortedEntries = [...entries].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    let streakDays = 0;
    const today = new Date();
    
    for (let i = 0; i < sortedEntries.length; i++) {
      const entryDate = new Date(sortedEntries[i].date);
      const daysDiff = Math.floor((today.getTime() - entryDate.getTime()) / (1000 * 60 * 60 * 24));
      
      if (daysDiff === i) {
        streakDays++;
      } else {
        break;
      }
    }

    // Weekly trend (last 7 days)
    const weeklyTrend = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const entry = getEntryByDate(dateStr);
      weeklyTrend.push(entry ? entry.mood : 0);
    }

    return {
      averageMood,
      totalEntries: entries.length,
      streakDays,
      moodDistribution,
      weeklyTrend,
    };
  };

  const exportData = () => {
    const data = {
      entries,
      exportDate: new Date().toISOString(),
      version: '1.0',
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mood-tracker-backup-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return {
    entries,
    loading,
    addEntry,
    updateEntry,
    deleteEntry,
    getEntryByDate,
    getStats,
    exportData,
  };
};